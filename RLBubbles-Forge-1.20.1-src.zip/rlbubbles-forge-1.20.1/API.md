# RLBubbles — API & Dialogue Pack Documentation

RLBubbles makes any `LivingEntity` occasionally show short floating **text** above its head —
thoughts, warnings, jokes, and reactions to the world, in the spirit of RLCraft. It renders text
only: no bubbles, backgrounds, borders, or panels (those are off by default).

This document covers the datapack dialogue format, the config, and the Java API for other mods.

---

## 1. Dialogue packs (datapacks)

Dialogue lives in `data/<namespace>/dialogue/*.json` and reloads with `/reload`. No code needed.

A file may contain a single entry, an array of entries, or an object with an `entries` array:

```json
{
  "entries": [
    {
      "entity": "minecraft:villager",
      "weight": 10,
      "text": "The crops look healthy today.",
      "conditions": { "time": "day" }
    },
    {
      "entity": "minecraft:villager",
      "weight": 2,
      "rare": true,
      "text": "I survived a dragon once."
    }
  ]
}
```

### Entry fields

| Field        | Type    | Default | Meaning |
|--------------|---------|---------|---------|
| `entity`     | string  | any     | Entity id (`minecraft:zombie`). Omit, or use `"*"` / `"any"`, to match every entity. |
| `weight`     | int     | 1       | Selection weight within the matching pool. |
| `rare`       | bool    | false   | Only eligible when rare dialogue is enabled and a ~10% roll passes. |
| `text`       | string  | —       | The line. Supports formatting & gradients (below). |
| `texts`      | [string]| —       | Several interchangeable lines; one is picked at random. Use instead of `text`. |
| `conditions` | object  | none    | All listed conditions must hold (below). |

### Conditions

| Key       | Values | Notes |
|-----------|--------|-------|
| `time`    | `day`, `night`, `sunrise`, `sunset` | Based on world day-time. |
| `weather` | `clear`, `rain`, `thunder` | |
| `health`  | `healthy`, `injured`, `critical` | Speaker's HP fraction (≤25% critical, <90% injured). |
| `biome`   | biome id, e.g. `minecraft:desert` | Exact match on the speaker's biome. |
| `nearby`  | array of `dragon`, `creeper`, `boss`, `hostile` | All listed threats must be within ~12 blocks. |

Unknown condition values are ignored (treated as unconstrained) rather than breaking the pack.

### Text formatting

- **Legacy color/format codes** with `&` (when `allowFormatting` is on):
  `"&cThe storm feels unnatural."` → red. Supports `&l` bold, `&o` italic, etc.
- **Gradients** (when `allowGradients` is on) via a leading directive:
  `"{gradient:FF0000,FFAA00} Burn."` interpolates each character from red to orange.
- **Unicode / emoji** pass straight through to the font.

---

## 2. Configuration

Config file: `config/rlbubbles-common.toml`. Key options:

```
enableVillagers / enablePassiveMobs / enableHostileMobs / enableBosses / enableModdedMobs = true
speechFrequency = 1.0      # global multiplier; 0 disables
maxDistance = 48           # blocks from a player for an entity to be considered
fadeInTicks = 10 / displayTicks = 80 / fadeOutTicks = 20
showShadow = true
enableContextualDialogue = true   # time/weather/threat/biome awareness
enableRareDialogue = true
showBubble = false / showBackground = false    # text-only by default
allowGradients = true / allowFormatting = true
maxMessagesPerEntity = 1
enableDatapacks = true
```

---

## 3. Java API

Maven/Gradle: depend on the RLBubbles jar; all entry points are in `com.rlbubbles.api.RLBubblesAPI`.

### Register dialogue programmatically (survives `/reload`)

```java
import com.rlbubbles.api.RLBubblesAPI;
import net.minecraft.resources.ResourceLocation;

// entity id (or null for "any"), text, weight, rare
RLBubblesAPI.registerDialogue(
    new ResourceLocation("alexsmobs", "grizzly_bear"),
    "Don't come near my cubs.", 10, false);
```

For conditional entries, build a `DialogueEntry` directly and pass it to
`RLBubblesAPI.registerDialogue(DialogueEntry)`.

### Trigger a message immediately (server-side, scripted events)

```java
RLBubblesAPI.showMessage(someLivingEntity, "{gradient:00FFFF,0000FF} The ritual begins.");
```

### Register a custom condition

```java
RLBubblesAPI.registerCondition("blood_moon", ctx ->
    MyModHooks.isBloodMoon(ctx.level));
```

(Reference it by name from your own provider logic or future condition extensions.)

### Register a dynamic entity provider

```java
RLBubblesAPI.registerEntityProvider((entity, ctx) -> {
    if (entity instanceof MyNpc npc) {
        return npc.getCurrentQuestLine();   // or null to defer to normal dialogue
    }
    return null;
});
```

Providers are consulted **before** static/datapack dialogue; the first non-null result wins.

---

## 4. How it works (performance)

- The **server** decides who speaks. It iterates **players**, scans only `LivingEntity`s within
  `maxDistance`, applies a cheap random gate, then builds a context and picks a line. Cost scales
  with players × local entities, not world size.
- It **never** modifies AI, pathfinding, or entity data — purely observational.
- The chosen line is sent as a tiny packet (`entity id + short string`) to all players tracking
  that entity, so everyone nearby sees the same message in singleplayer, LAN, and dedicated.
- The **client** renders floating text only, billboarded toward the camera, with fade-in,
  upward drift, and fade-out. Bubbles are stored in a small per-entity map advanced once per tick.
- Dialogue pools are cached after each datapack reload; selection is O(entries-for-this-entity).

---

*RLBubbles — a modern, data-driven successor to the classic RLCraft / Dynamic Surroundings
chatter system. Floating text only.*
